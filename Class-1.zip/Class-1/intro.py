# Importing OpenCV module
import cv2

# Reading Image
cv2.imread(path)

# Colour Channel Splitting returns three values of Blue, Green, Red
b, g, r = cv2.split(img_variable)

###          Arithmetic Operator         ###

# Image Addition
cv2.add(img1, img2)

# Image Addition more smoother way
cv2.addWeighted(img1, wt1, img2, wt2, gammaValue)

# Image Subtraction
cv2.subtract(img1, img2)


###          Bitwise Operator            ###

# Bitwise AND
cv2.bitwise_and(img1, img2, mask = None)

# Bitwise_OR
cv2.bitwise_or(img1, img2, mask = None)

# Bitwise_XOR
cv2.bitwise_xor(img1, img2, mask = None)

# Bitwise_NOT
cv2.bitwise_not(img, mask = None)

# Saving Image
cv2.imwrite(path,img_variable)

# Displaying Image
cv2.imshow(Window_name,img_variable)

# Holding the Display Window by passing 0
cv2.waitKey(0)

# Freeing Up memory
cv2.destroyAllWindows()